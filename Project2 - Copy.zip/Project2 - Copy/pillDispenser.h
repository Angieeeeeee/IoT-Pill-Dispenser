/*
 * pillDispenser.h
 *
 *  Created on: Apr 7, 2025
 *      Author: arshd
 */

#ifndef PILLDISPENSER_H_
#define PILLDISPENSER_H_




//change pulseWidth to 5 or 25 to get 0 degrees of 180

//hex display
#define A_mask 64           //7 - PB6
#define B_mask 128          //6 - PB7
#define C_mask 2            //4 - PB1
#define D_mask 1            //2 - PB0
#define E_mask 32           //1 - PB5
#define F_mask 1            //9 - PE0
#define G_mask 4            //10 -PB2

//bit banding
#define A  (*((volatile uint32_t *)(0x42000000 + (0x400053FC-0x40000000)*32 + 6*4)))
#define B  (*((volatile uint32_t *)(0x42000000 + (0x400053FC-0x40000000)*32 + 7*4)))
#define C  (*((volatile uint32_t *)(0x42000000 + (0x400053FC-0x40000000)*32 + 1*4)))
#define D  (*((volatile uint32_t *)(0x42000000 + (0x400053FC-0x40000000)*32 + 0*4)))
#define E  (*((volatile uint32_t *)(0x42000000 + (0x400053FC-0x40000000)*32 + 5*4)))
#define F  (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 0*4)))
#define G  (*((volatile uint32_t *)(0x42000000 + (0x400053FC-0x40000000)*32 + 2*4)))

//clear dispense flag
void clearDips();

//servo motor

#define PA6_MASK 64 // PA6
#define PA6 (*((volatile uint32_t *)(0x42000000 + (0x400043FC-0x40000000)*32 + 6*4)))

//pb mask pe4
#define PB_mask 16

//pb bit band
#define PB  (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 4*4)))

//led mask // pe5
#define LED_mask 32

//led bit band
#define LED  (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 5*4)))



// PIR sensor on PORT D pin 2 (PD2)
#define PIR_PORT PORTD
#define PIR_PIN  2

#define PIR  (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 2*4)))






uint8_t dispenseCount;
uint32_t dispenseInterval;




void initServo();
void init_hex();
void hexNum(int i);

void initLedPB();


void dispenseISR();

void dailyNotficationISR();

//servo utility
void servoUp();

void servoDown();
void initPIRSensor();

uint8_t isDispensing();

void ledOn();
void ledOff();

void setDips(uint8_t dispense);

void incMissedCount();
uint8_t waitPbPress(void);
uint8_t waitPIR(void);

#endif /* PILLDISPENSER_H_ */
