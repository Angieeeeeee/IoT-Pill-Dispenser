#include <stdint.h>
#include <stdbool.h>
#include "clock.h"
#include "wait.h"
#include "tm4c123gh6pm.h"
#include "gpio.h"
#include "pillDispenser.h"
#include <stdio.h>
#include "mqtt.h"
#include "uart0.h"
#include "timer.h"



volatile uint32_t tickCounter = 0;
volatile uint32_t pulseWidth = 15;
volatile uint32_t periodSystick = 200;


uint8_t dips = 0;
//for how many missed message after 24 hours - implement later
uint32_t missedCount = 0;

uint32_t timeSystick;

void clearDips()
{
    dips = 0;
}


uint8_t isDispensing()
{
    return dips;
}

void setDips(uint8_t dispense)
{
    dips = dispense;
}

void ledOn()
{
    LED = 1;
}

void ledOff()
{
    LED = 0;
}
void incMissedCount()
{
    missedCount++;
}



void SysTickHandler() {

    tickCounter++;

    if (tickCounter < pulseWidth)
    {
        PA6 = 1; // High pulse
    } else
    {
        PA6 = 0; // Low for rest of period
    }
    if (tickCounter >= periodSystick)
    {
        tickCounter = 0; // Reset for next 20 ms
    }

    //for keeping track of time
    timeSystick++;
}

void initServo() {

    // Initialize system clock to 40 MHz
    initSystemClockTo40Mhz();

    // Enable clocks
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R0; // Port A
    _delay_cycles(3);

    // Configure PA6 as GPIO output
    GPIO_PORTA_DIR_R |= PA6_MASK;
    GPIO_PORTA_DEN_R |= PA6_MASK;


    // Configure SysTick for 0.1 ms ticks
    NVIC_ST_CTRL_R = 0;              // Disable SysTick during setup
    NVIC_ST_RELOAD_R = 4000 - 1;     // 0.1 ms at 40 MHz (4000 ticks - 1)
    NVIC_ST_CURRENT_R = 0;           // Clear current value
    NVIC_ST_CTRL_R = NVIC_ST_CTRL_CLK_SRC | NVIC_ST_CTRL_INTEN | NVIC_ST_CTRL_ENABLE;



}





void init_hex()
{
    // Enable clocks
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R1; // Port B
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R4; // Port E
    _delay_cycles(3);

    // Configure port B and E as GPIO output
    GPIO_PORTB_DIR_R |= A_mask | B_mask | C_mask | D_mask | E_mask | G_mask;
    GPIO_PORTB_DEN_R |= A_mask | B_mask | C_mask | D_mask | E_mask | G_mask;

    GPIO_PORTE_DIR_R |= F_mask;
    GPIO_PORTE_DEN_R |= F_mask;
}

//sets the hex display to character
void hexNum(int i)
{

    switch(i)
    {
    case 0:
        A = 1; B = 1; C = 1; D = 1; E = 1; F = 1; G = 0;
        break;
    case 1:
        A = 0; B = 1; C = 1; D = 0; E = 0; F = 0; G = 0;
        break;
    case 2:
        A = 1; B = 1; C = 0; D = 1; E = 1; F = 0; G = 1;
        break;
    case 3:
        A = 1; B = 1; C = 1; D = 1; E = 0; F = 0; G = 1;
        break;
    case 4:
        A = 0; B = 1; C = 1; D = 0; E = 0; F = 1; G = 1;
        break;
    case 5:
        A = 1; B = 0; C = 1; D = 1; E = 0; F = 1; G = 1;
        break;
    case 6:
        A = 1; B = 0; C = 1; D = 1; E = 1; F = 1; G = 1;
        break;
    case 7:
        A = 1; B = 1; C = 1; D = 0; E = 0; F = 0; G = 0;
        break;
    case 8:
        A = 1; B = 1; C = 1; D = 1; E = 1; F = 1; G = 1;
        break;
    case 9:
        A = 1; B = 1; C = 1; D = 1; E = 0; F = 1; G = 1;
        break;
    default: A = 0; B = 0; C = 0; D = 0; E = 0; F = 0; G = 0;
    }
}

void initLedPB()
{
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R4; // Port E
    _delay_cycles(3);

    GPIO_PORTE_DIR_R |= LED_mask;
    GPIO_PORTE_DEN_R |= LED_mask;

    GPIO_PORTE_DIR_R &= ~PB_mask;
    GPIO_PORTE_DEN_R |= PB_mask;

    GPIO_PORTE_PUR_R |= PB_mask;
}

void initPIRSensor() // Call in main
{
    enablePort(PIR_PORT);
    selectPinDigitalInput(PIR_PORT, PIR_PIN);
    setPinCommitControl(PIR_PORT, PIR_PIN);

}

uint8_t waitPbPress(void)
{
    timeSystick = 0;
    uint32_t startTime = timeSystick;
    uint32_t currTime;




    while(PB)
    {
        currTime = timeSystick;

        if((currTime - startTime) > 100000) //if 60 seconds have passed since time to dispense
        {

            return 0;
        }
    }


    return 1;
}

uint8_t waitPIR(void)
{
    timeSystick = 0;
    uint32_t startTime = timeSystick;
    uint32_t currTime;



    while(!PIR)
    {
        currTime = timeSystick;
        putcUart0(PIR + '0');

        if((currTime - startTime) > 100000) //if 60 seconds have passed since time to dispense
        {
            return 0;
        }
    }


    return 1;
}

void servoUp()
{
    pulseWidth = 5;
}

void servoDown()
{
    pulseWidth = 25;
}




void dispenseISR(){

//    //holds messages
//    char topic[25];
//    char data [25];
    setDips(1);

}



void dailyNotficationISR()
{

    char buffer[50];

    sprintf(buffer, "Today's Missed Doses: %d\n", missedCount);
    publishMqtt("PillDailyReport", buffer);
    missedCount = 0;

}




//int main(void) {
//
//    //servo test
//    initServo();
//    initLedPB();
//    initPIRSensor();
//    init_hex();
//
//
//
//
//
////    //debug
////    initUart0();
////    setUart0BaudRate(115200, 40e6);
////    while(1){
////        putcUart0(PIR + '0');
////        putcUart0('\n');
////    }
////    //debug
////
////
////
////
////
////
////    dispenseCount = 4;
////    dispenseInterval = 20;
////
////    dispenseISR();
////
////    while(1);
//
////    while(1)
////    {
////        servoUp();
////    }
//
// //   setting pulseWidth to 0 will pause the servo
//
//    while (1) {
//        // 0
//        //pulseWidth = 5;
//        servoUp();
//        waitMicrosecond(1000000);  // Wait 1 second
//
//
//        // 180
//        //pulseWidth = 25;
//        servoDown();
//        waitMicrosecond(1000000);   // Wait 1 second
//    }
//
//
//
//   // hex test
////    init_hex();
////
////    waitPbPress();
////
////    hexNum(1);
////    waitMicrosecond(1000000);
////    hexNum(2);
////    waitMicrosecond(1000000);
////    hexNum(3);
////    waitMicrosecond(1000000);
////    hexNum(4);
////    waitMicrosecond(1000000);
////    hexNum(5);
////    waitMicrosecond(1000000);
////    hexNum(6);
////    waitMicrosecond(1000000);
////    hexNum(7);
////    waitMicrosecond(1000000);
////    hexNum(8);
////    waitMicrosecond(1000000);
////    hexNum(9);
////    waitMicrosecond(1000000);
////
////    while(1)
////    {
////        hexNum(1);
////        waitMicrosecond(1000000);
////        hexNum(2);
////        waitMicrosecond(1000000);
////        hexNum(3);
////        waitMicrosecond(1000000);
////        hexNum(4);
////        waitMicrosecond(1000000);
////        hexNum(5);
////        waitMicrosecond(1000000);
////        hexNum(6);
////        waitMicrosecond(1000000);
////        hexNum(7);
////        waitMicrosecond(1000000);
////        hexNum(8);
////        waitMicrosecond(1000000);
////        hexNum(9);
////        waitMicrosecond(1000000);
////    }
////    return 0;
//}
