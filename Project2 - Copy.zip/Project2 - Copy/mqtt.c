// MQTT Library (includes framework only)
// Jason Losh
//Arshdeep Singh
//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: -
// Target uC:       -
// System Clock:    -

// Hardware configuration:
// -

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include "mqtt.h"
#include "timer.h"
#include "arp.h"

// ------------------------------------------------------------------------------
//  Globals
// ------------------------------------------------------------------------------

// ------------------------------------------------------------------------------
//  Structures
// ------------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

//defind from other

#define MAX_PACKET_SIZE 1518
#define MAX_MQTT_SIZE 1000

uint16_t packetId;


void sendConnectMessage(etherHeader* ether)
{
//
//    // client name is client123 (9 bytes)
//    // mqtt connect message size is 23 bytes
//    uint8_t ip[4];
//    uint8_t destIp[4];
//
//    getIpAddress(ip);
//    getIpMqttBrokerAddress(destIp);
//
//    uint8_t ehtbuffer[MAX_PACKET_SIZE];
//    etherHeader *ether = (etherHeader*) ehtbuffer;

    socket* s = getSocketZero();

    //connect message is 23 ytes
    uint8_t buffer[MAX_MQTT_SIZE];

    uint8_t size = 0;
    //mqtt control header
    buffer[size++] = (MQTT_CONNECT<<4);

    //calculate remaining length index so I can add length dynamically later
    uint8_t indexRML = size;
    size++;

    //-----------------start variable header---------------
    //protocol name length
    uint16_t protocolNameSize = htons(0x0004); // 0x00 0x04
    memcpy(&buffer[size], &protocolNameSize, 2);
    size += 2;

    //protocol name
    memcpy(&buffer[size], "MQTT", 4);
    size += 4;

    //protocol Level
    buffer[size++] = 0x04; //v3.1.1

    //connfect flag
    buffer[size++] = 0b00000010; // bit 1 for clean session everytime

    //keep alive
    uint16_t keepAlive = htons(120); // 2mins
    memcpy(&buffer[size], &keepAlive, 2);
    size += 2;


    //---------------start payload-----------------------

    //client Id  size
    uint16_t clientIdSize = htons(9);// 9 bytes for the client id name
    memcpy(&buffer[size], &clientIdSize, 2);
    size += 2;

    //client id
    memcpy(&buffer[size], "Client123", 9);
    size += 9;

    //add in remaining length
    buffer[indexRML] = size - indexRML - 1;


    sendTcpMessage(ether,s, PSH | ACK, buffer, size);
    //update seq number
    s->sequenceNumber = s->sequenceNumber + size;
}


void connectMqtt()
{

    packetId = 1;
        uint8_t ip[4];
        uint8_t destIp[4];

        getIpAddress(ip);
        getIpMqttBrokerAddress(destIp);

        uint8_t buffer[MAX_PACKET_SIZE];
        etherHeader *ether = (etherHeader*) buffer;



        if(getTcpState(0) == TCP_CLOSED)
        {

            sendArpRequest(ether, ip, destIp);
            setTcpState(0,ARP_SENT);
            startPeriodicTimer(handleARPTimeout, 5);
        }
}



void disconnectMqtt()
{

    if(getTcpState(0) != TCP_CLOSED){


        uint8_t ehtbuffer[MAX_PACKET_SIZE];
        etherHeader *ether = (etherHeader*) ehtbuffer;
        socket* s = getSocketZero();

        //connect message is 23 ytes
        uint8_t buffer[MAX_MQTT_SIZE];

        uint8_t size = 0;
        //mqtt control header
        buffer[size++] = (MQTT_DISCONNECT<<4);

        //calculate remaining length index so I can add length dynamically later
        buffer[size++] = 0;



        sendTcpMessage(ether,s, PSH | ACK, buffer, size);
        //update seq number
        s->sequenceNumber = s->sequenceNumber + size;

    }


}

void publishMqtt(char strTopic[], char strData[])
{

        uint8_t ehtbuffer[MAX_PACKET_SIZE];
        etherHeader *ether = (etherHeader*) ehtbuffer;

        socket* s = getSocketZero();

        //connect message is 23 ytes
        uint8_t buffer[MAX_MQTT_SIZE];

        uint8_t size = 0;
        //mqtt control header
        buffer[size++] = (MQTT_PUBLISH<<4);

        //calculate remaining length index so I can add length dynamically later
        uint8_t indexRML = size;
        size++;

        //-----------------start variable header---------------
        //topic name name length
        uint16_t topicNameSizeRaw = strlen(strTopic);
        uint16_t topicNameSize = htons(topicNameSizeRaw); // 0x00 0x04
        memcpy(&buffer[size], &topicNameSize, 2);
        size += 2;

        //topic name
        memcpy(&buffer[size], strTopic, topicNameSizeRaw);
        size += topicNameSizeRaw;


        //---------------start payload-----------------------

        //payload data

        uint16_t dataSize = strlen(strData);
        memcpy(&buffer[size], strData, dataSize);
        size += dataSize;


        //add in remaining length
        buffer[indexRML] = size - indexRML - 1;


        sendTcpMessage(ether,s, PSH | ACK, buffer, size);
        //update seq number
        s->sequenceNumber = s->sequenceNumber + size;

}

void subscribeMqtt(char strTopic[])
{

    uint8_t ehtbuffer[MAX_PACKET_SIZE];
    etherHeader *ether = (etherHeader*) ehtbuffer;

    socket* s = getSocketZero();

    //connect message is 23 ytes
    uint8_t buffer[MAX_MQTT_SIZE];

    uint8_t size = 0;
    //mqtt control header
    buffer[size++] = (MQTT_SUBSCRIBE<<4 | 0x2);

    //calculate remaining length index so I can add length dynamically later
    uint8_t indexRML = size;
    size++;

    //-----------------start variable header---------------

    uint16_t htonPacketId = htons(packetId);
    memcpy(&buffer[size], &htonPacketId, 2);
    size += 2;

    //---------------start payload-----------------------

    //payload data

    //topic name name length
    uint16_t topicNameSizeRaw = strlen(strTopic);
    uint16_t topicNameSize = htons(topicNameSizeRaw); // 0x00 0x04
    memcpy(&buffer[size], &topicNameSize, 2);
    size += 2;

    //topic name
    memcpy(&buffer[size], strTopic, topicNameSizeRaw);
    size += topicNameSizeRaw;


    //qos Level
    buffer[size++] = 0; //Qos 0


    //add in remaining length
    buffer[indexRML] = size - indexRML - 1;


    sendTcpMessage(ether,s, PSH | ACK, buffer, size);
    //update seq number
    s->sequenceNumber = s->sequenceNumber + size;

}

void unsubscribeMqtt(char strTopic[])
{

    uint8_t ehtbuffer[MAX_PACKET_SIZE];
    etherHeader *ether = (etherHeader*) ehtbuffer;

    socket* s = getSocketZero();

    //connect message is 23 ytes
    uint8_t buffer[MAX_MQTT_SIZE];

    uint8_t size = 0;
    //mqtt control header
    buffer[size++] = (MQTT_UNSUBSCRIBE<<4 | 0x2);

    //calculate remaining length index so I can add length dynamically later
    uint8_t indexRML = size;
    size++;

    //-----------------start variable header---------------

    uint16_t htonPacketId = htons(packetId);
    memcpy(&buffer[size], &htonPacketId, 2);
    size += 2;

    //---------------start payload-----------------------

    //payload data

    //topic name name length
    uint16_t topicNameSizeRaw = strlen(strTopic);
    uint16_t topicNameSize = htons(topicNameSizeRaw); // 0x00 0x04
    memcpy(&buffer[size], &topicNameSize, 2);
    size += 2;

    //topic name
    memcpy(&buffer[size], strTopic, topicNameSizeRaw);
    size += topicNameSizeRaw;



    //add in remaining length
    buffer[indexRML] = size - indexRML - 1;


    sendTcpMessage(ether,s, PSH | ACK, buffer, size);
    //update seq number
    s->sequenceNumber = s->sequenceNumber + size;

}

void KeepAliveMqtt()
{
    putsUart0("keep alive message sent\n");


    uint8_t ehtbuffer[MAX_PACKET_SIZE];
    etherHeader *ether = (etherHeader*) ehtbuffer;
    socket* s = getSocketZero();

    //connect message is 23 ytes
    uint8_t buffer[MAX_MQTT_SIZE];

    uint8_t size = 0;
    //mqtt control header
    buffer[size++] = (MQTT_PINGREQ<<4);

    //calculate remaining length index so I can add length dynamically later
    buffer[size++] = 0;



    sendTcpMessage(ether,s, PSH | ACK, buffer, size);
    //update seq number
    s->sequenceNumber = s->sequenceNumber + size;

}

void incrementPacketId(){
    packetId++;
}


