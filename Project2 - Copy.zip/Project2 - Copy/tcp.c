// TCP Library (includes framework only)
// Jason Losh
//Arshdeep Singh
//Angelina Abuhilal
//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: -
// Target uC:       -
// System Clock:    -

// Hardware configuration:
// -

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arp.h"
#include "tcp.h"
#include "timer.h"
#include "mqtt.h"
#include "pillDispenser.h"

// ------------------------------------------------------------------------------
//  Globals
// ------------------------------------------------------------------------------

#define MAX_TCP_PORTS 4

uint16_t tcpPorts[MAX_TCP_PORTS];
uint8_t tcpPortCount = 0;
uint8_t tcpState[MAX_TCP_PORTS];

// 0 means not disconnected, 1 means connected
uint8_t MQTTState;



// defined from other
#define MAX_PACKET_SIZE 1518
#define MAX_TOPIC_NAME 100
// ------------------------------------------------------------------------------
//  Structures
// ------------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

uint8_t getTcpState0()
{
    return tcpState[0];
}

void setTcpState0(uint8_t state){
    tcpState[0] = state;
}

uint8_t getMQTTState()
{
    return MQTTState;
}

void setMQTTState(uint8_t state)
{
    MQTTState = state;
}

//flag setter funciton
void handleARPTimeout()
{
        uint8_t ip[4];
        uint8_t destIp[4];

        getIpAddress(ip);
        getIpMqttBrokerAddress(destIp);

        uint8_t buffer[MAX_PACKET_SIZE];
        etherHeader *ether = (etherHeader*) buffer;

        if(getTcpState(0) == ARP_SENT)
        {
            sendArpRequest(ether, ip, destIp);
            setTcpState(0,ARP_SENT);
        }


        putsUart0("handleARP called\n");

}

void handleTCPSYNTimeout(){


    uint8_t buffer[MAX_PACKET_SIZE];
    etherHeader *ether = (etherHeader*) buffer;

    if(getTcpState(0) ==  TCP_SYN_SENT)
    {
             sendTcpResponse(ether, getSocketZero(), SYN);
             setTcpState(0,TCP_SYN_SENT);
    }


    putsUart0("handle tcp syn timeout called\n");

}

// Set TCP state
void setTcpState(uint8_t instance, uint8_t state)
{
    tcpState[instance] = state;
}

// Get TCP state
uint8_t getTcpState(uint8_t instance)
{
    return tcpState[instance];
}

// Determines whether packet is TCP packet
// Must be an IP packet
bool isTcp(etherHeader* ether)
{
    ipHeader *ip = (ipHeader*)ether->data;
    uint8_t ipHeaderLenght = ip->size * 4;

    tcpHeader *tcp = (tcpHeader*)((uint8_t*)ip + ipHeaderLenght);
    bool ok;
    uint16_t tmp16;
    uint32_t sum = 0;

    ok = (ip->protocol == PROTOCOL_TCP);

    if(ok)
    {
        //sum over the psudo header
        sumIpWords(ip->sourceIp, 8, &sum);
        tmp16 = ip->protocol;
        sum += (tmp16 & 0xff) << 8;
        //sumIpWords(&tcp->length, 2 , &sum);
        // adding tcp header and data
        uint16_t tcpLength = ntohs(ip->length) - ip->size*4;
        uint16_t tcpNetLength = htons(tcpLength);
        sumIpWords(&tcpNetLength, 2 , &sum);
        sumIpWords(tcp, tcpLength, &sum);
        ok = (getIpChecksum(sum) == 0);
    }
    return ok;
}



bool isTcpSyn(etherHeader *ether)
{

    ipHeader *ip = (ipHeader*)ether->data;
    uint8_t ipHeaderLenght = ip->size * 4;

    tcpHeader *tcp = (tcpHeader*)((uint8_t*)ip + ipHeaderLenght);

    uint16_t offset = ntohs(tcp->offsetFields);


    if(offset & SYN)
        return true;
    else
        return false;
}

bool isTcpAck(etherHeader *ether)
{
    ipHeader *ip = (ipHeader*)ether->data;
    uint8_t ipHeaderLenght = ip->size * 4;

    tcpHeader *tcp = (tcpHeader*)((uint8_t*)ip + ipHeaderLenght);

    uint16_t offset = ntohs(tcp->offsetFields);

    if(offset & ACK)
        return true;
    else
        return false;
}


bool isTcpFin(etherHeader *ether)
{
    ipHeader *ip = (ipHeader*)ether->data;
    uint8_t ipHeaderLenght = ip->size * 4;

    tcpHeader *tcp = (tcpHeader*)((uint8_t*)ip + ipHeaderLenght);

    uint16_t offset = ntohs(tcp->offsetFields);

    if(offset & FIN)
        return true;
    else
        return false;
}

bool isTcpRst(etherHeader *ether)
{
    ipHeader *ip = (ipHeader*)ether->data;
    uint8_t ipHeaderLenght = ip->size * 4;

    tcpHeader *tcp = (tcpHeader*)((uint8_t*)ip + ipHeaderLenght);

    uint16_t offset = ntohs(tcp->offsetFields);

    if(offset & RST)
        return true;
    else
        return false;
}


void sendTcpPendingMessages(etherHeader *ether)
{



}

uint8_t getMQTTType(tcpHeader* tcp)
{
    uint8_t packetType = tcp->data[0] >> 4;

    return packetType;
}



void processTcpResponse(etherHeader *ether)
{


    ipHeader *ip = (ipHeader*)ether->data;
    uint8_t ipHeaderLenght = ip->size * 4;

    tcpHeader *tcp = (tcpHeader*)((uint8_t*)ip + ipHeaderLenght);
    socket* s = getSocketZero();


    //do an if for anytime reseving rst, set state back to closed
    if(isTcpRst(ether))
    {
        setTcpState(0, TCP_CLOSED);
        MQTTState = MQTTDISCONNECTED;
        stopTimer(handleTCPSYNTimeout);
        stopTimer(KeepAliveMqtt);
        stopTimer(handleARPTimeout);

    }


    if(getTcpState(0) == TCP_SYN_SENT)
    {

        if(isTcpAck(ether) && isTcpSyn(ether))
        {

            stopTimer(handleTCPSYNTimeout);

            putsUart0("is ack and sync\n");

            // seq not incrmeented for ack

            uint32_t acknumber = ntohl(tcp->sequenceNumber);
            s->acknowledgementNumber = acknumber + 1;


            setTcpState(0, TCP_ESTABLISHED);
            sendTcpResponse(ether, s, ACK);

            //finally send the connect message in tcp
            sendConnectMessage(ether);

        }
    }



    //if in established state; do
    if(getTcpState(0) == TCP_ESTABLISHED)
    {

        //if recieve fin from server after disconnect
        if(isTcpFin(ether))
        {

            putsUart0("FIN 1 called\n");

            // dont update teh sequence number
            s->sequenceNumber = s->sequenceNumber;
            //tcp ack is in big endian

            uint32_t acknumber = ntohl(tcp->sequenceNumber);
            s->acknowledgementNumber = acknumber + 1;


            setTcpState(0, TCP_CLOSING);
            sendTcpResponse(ether, s, ACK);
            sendTcpResponse(ether, s, FIN | ACK);
            putsUart0("\n TCP CONNECTION CLOSING\n");

        }
        else  //handle incoming mqtt messages
        {
            if(getMQTTType(tcp) == MQTT_CONNACK)
            {
                putsUart0("CONNACK RECIEVED, SENDING ACK\n");
                // seq not incrmeented for ack

                uint32_t acknumber = ntohl(tcp->sequenceNumber);
                s->acknowledgementNumber = acknumber + tcp->data[1] + 2;


                setTcpState(0, TCP_ESTABLISHED);
                sendTcpResponse(ether, s, ACK);

                //mqtt is connected
                MQTTState = MQTTCONNECTED;


                //set pingresp
                startPeriodicTimer(KeepAliveMqtt, 60);

                //sending auto submessage ? temp
                subscribeMqtt("pillsetupdata");

            }
            else if(getMQTTType(tcp) == MQTT_PINGRESP)
            {
                putsUart0("Keep Alive ping recieved, sending ack\n");

                uint32_t acknumber = ntohl(tcp->sequenceNumber);
                s->acknowledgementNumber = acknumber + tcp->data[1] + 2;

                sendTcpResponse(ether, s, ACK);

            }
            else if(getMQTTType(tcp) == MQTT_SUBACK)
            {
                putsUart0("SUBACK recieved, sending ack\n");

                uint32_t acknumber = ntohl(tcp->sequenceNumber);
                s->acknowledgementNumber = acknumber + tcp->data[1] + 2;

                sendTcpResponse(ether, s, ACK);

                incrementPacketId();


            }
            else if(getMQTTType(tcp) == MQTT_UNSUBACK)
            {
                putsUart0("UNSUBACK recieved, sending ack\n");

                uint32_t acknumber = ntohl(tcp->sequenceNumber);
                s->acknowledgementNumber = acknumber + tcp->data[1] + 2;

                sendTcpResponse(ether, s, ACK);

                incrementPacketId();

            }
            else if(getMQTTType(tcp) == MQTT_PUBLISH) // recieve message from pill dispense sender
            {
                putsUart0("DATA RECIEVED:\n");


                uint32_t acknumber = ntohl(tcp->sequenceNumber);
                s->acknowledgementNumber = acknumber + tcp->data[1] + 2;

                sendTcpResponse(ether, s, ACK);



                //size variable to loop through the data
                uint8_t size = 1;

                //remaining legnth
                uint8_t remainingLength = tcp->data[size++];

                //buffer to store topic name and data; max chars is 100
                char buffer[MAX_TOPIC_NAME];
                char bufferData[MAX_TOPIC_NAME];

                uint16_t stringLenRaw;
                memcpy(&stringLenRaw, &tcp->data[size], 2);
                uint16_t stringLen = ntohs(stringLenRaw); // get little endian topic name length

                size += 2; //2 for the size of topic name field

                uint16_t i;

                for(i = 0; i < stringLen; i++)
                {
                    buffer[i] = tcp->data[size + i];
                }

                size+= i;
                buffer[i] = '\0';

                putsUart0("From topic: ");
                putsUart0(buffer);

                putsUart0(" data: ");
                //rest of the data

                for(i = 0; i <= (remainingLength - size + 1); i++)
                {
                    bufferData[i] = tcp->data[size + i];
                }

                bufferData[i] = '\0';

                putsUart0(bufferData);
                putsUart0("\n");

                //handling set up for pill machine

                if(strcmp(buffer, "pillsetupdata") == 0)
                {
                    clearDips();
                    dispenseCount = (uint8_t)bufferData[0] - '0';
                    dispenseInterval = (uint32_t)atoi(bufferData + 1);

                    startPeriodicTimer(dispenseISR, dispenseInterval);

                    //86400 seconds is the number of seconds in a day
                    startPeriodicTimer(dailyNotficationISR, 60);
                }

            }

        }
    }


    if(getTcpState(0) == TCP_CLOSING)
    {
        if(isTcpAck(ether)){

            //to stop client from sending rst on the next cycle
            getEtherPacket(ether, MAX_PACKET_SIZE);



            stopTimer(handleTCPSYNTimeout);
            stopTimer(KeepAliveMqtt);
            stopTimer(handleARPTimeout);

            putsUart0("\n TCP CONNECTION CLOSED\n");
            setTcpState(0, TCP_CLOSED);
            MQTTState = MQTTDISCONNECTED;
        }
    }


}

void processTcpArpResponse(etherHeader *ether)
{

    if(getTcpState(0) == ARP_SENT)
    {
        stopTimer(handleARPTimeout);

        getSocketInfoFromArpResponse(ether, getSocketZero());

        socket* s = getSocketZero();
        s->localPort = 55;
        s->remotePort = 1883;
        s->sequenceNumber = rand();
        s->acknowledgementNumber = 0;

        sendTcpResponse(ether, s, SYN);

        //increment sequence number, since a seq was sent
        s->sequenceNumber = s->sequenceNumber  + 1;
        setTcpState(0,TCP_SYN_SENT);
        startPeriodicTimer(handleTCPSYNTimeout, 5);
    }


}

void setTcpPortList(uint16_t ports[], uint8_t count)
{

}

bool isTcpPortOpen(etherHeader *ether)
{
       ipHeader *ip = (ipHeader*)ether->data;
       uint8_t ipHeaderLenght = ip->size * 4;
       tcpHeader *tcp = (tcpHeader*)((uint8_t*)ip + ipHeaderLenght);

       uint16_t destPort = ntohs(tcp->destPort);

       if(destPort == 55 && getTcpState(0) != TCP_CLOSED)
       {
           putsUart0("Port55 has a message\n");
           return true;
       }
       return false;
}

void sendTcpResponse(etherHeader *ether, socket* s, uint16_t flags)
{
       uint8_t i;
       uint16_t j;
       uint32_t sum;
       uint16_t tmp16;
       uint16_t TcpLength;
       uint8_t *copyData;
       uint8_t localHwAddress[6];
       uint8_t localIpAddress[4];

       // Ether frame
       getEtherMacAddress(localHwAddress);
       getIpAddress(localIpAddress);
       for (i = 0; i < HW_ADD_LENGTH; i++)
       {   //hard coding ip and hw address for now

           ether->destAddress[i] = s->remoteHwAddress[i];
           //ether->destAddress[i] = s.remoteHwAddress[i];
           ether->sourceAddress[i] = localHwAddress[i];
       }
       ether->frameType = htons(TYPE_IP);

       // IP header
       ipHeader* ip = (ipHeader*)ether->data;
       ip->rev = 0x4;
       ip->size = 0x5;
       ip->typeOfService = 0;
       ip->id = 0;
       ip->flagsAndOffset = 0;
       ip->ttl = 128;
       ip->protocol = PROTOCOL_TCP;
       ip->headerChecksum = 0;
       for (i = 0; i < IP_ADD_LENGTH; i++)
       {
            //hard coded ip address
           ip->destIp[i] = s->remoteIpAddress[i];
           ip->sourceIp[i] = localIpAddress[i];
       }
       uint8_t ipHeaderLength = ip->size * 4;

       // UDP header
       tcpHeader* tcp = (tcpHeader*)((uint8_t*)ip + (ip->size * 4));

       // adjust lengths
       TcpLength = sizeof(tcpHeader);
       ip->length = htons(ipHeaderLength + TcpLength);
       // 32-bit sum over ip header
       calcIpChecksum(ip);

       // 32-bit sum over pseudo-header
       sum = 0;
       sumIpWords(ip->sourceIp, 8, &sum);
       tmp16 = ip->protocol;
       sum += (tmp16 & 0xff) << 8;

       uint16_t tcpNetLength = htons(TcpLength);
       sumIpWords(&tcpNetLength, 2, &sum);

       // add tcp header
       tcp->checksum = 0;

       //addition info
       tcp->acknowledgementNumber = htonl(s->acknowledgementNumber);
       tcp->sequenceNumber = htonl(s->sequenceNumber);
       tcp->destPort = htons(s->remotePort);
       tcp->sourcePort = htons(s->localPort);
       tcp->offsetFields = htons((5 << 12) | flags);

       tcp->windowSize = htons(65535);
       *(tcp->data) = NULL;
       tcp->urgentPointer = 0;

       sumIpWords(tcp, TcpLength, &sum);
       tcp->checksum = getIpChecksum(sum);

       // send packet with size = ether + udp hdr + ip header + udp_size
       putEtherPacket(ether, sizeof(etherHeader) + ipHeaderLength + TcpLength);
}

// Send TCP message
void sendTcpMessage(etherHeader *ether, socket* s, uint16_t flags, uint8_t data[], uint16_t dataSize)
{
    uint8_t i;
    uint16_t j;
    uint32_t sum;
    uint16_t tmp16;
    uint16_t TcpLength;
    uint8_t *copyData;
    uint8_t localHwAddress[6];
    uint8_t localIpAddress[4];

    // Ether frame
    getEtherMacAddress(localHwAddress);
    getIpAddress(localIpAddress);
    for (i = 0; i < HW_ADD_LENGTH; i++)
    {   //hard coding ip and hw address for now

        ether->destAddress[i] = s->remoteHwAddress[i];
        //ether->destAddress[i] = s.remoteHwAddress[i];
        ether->sourceAddress[i] = localHwAddress[i];
    }
    ether->frameType = htons(TYPE_IP);

    // IP header
    ipHeader* ip = (ipHeader*)ether->data;
    ip->rev = 0x4;
    ip->size = 0x5;
    ip->typeOfService = 0;
    ip->id = 0;
    ip->flagsAndOffset = 0;
    ip->ttl = 128;
    ip->protocol = PROTOCOL_TCP;
    ip->headerChecksum = 0;
    for (i = 0; i < IP_ADD_LENGTH; i++)
    {
         //hard coded ip address
        ip->destIp[i] = s->remoteIpAddress[i];
        ip->sourceIp[i] = localIpAddress[i];
    }
    uint8_t ipHeaderLength = ip->size * 4;

    // UDP header
    tcpHeader* tcp = (tcpHeader*)((uint8_t*)ip + (ip->size * 4));

    // adjust lengths
    TcpLength = sizeof(tcpHeader) + dataSize;
    ip->length = htons(ipHeaderLength + TcpLength);
    // 32-bit sum over ip header
    calcIpChecksum(ip);



    // copy data
    copyData = tcp->data;
    for (j = 0; j < dataSize; j++)
        copyData[j] = data[j];

    // 32-bit sum over pseudo-header
    sum = 0;
    sumIpWords(ip->sourceIp, 8, &sum);
    tmp16 = ip->protocol;
    sum += (tmp16 & 0xff) << 8;

    uint16_t tcpNetLength = htons(TcpLength);
    sumIpWords(&tcpNetLength, 2, &sum);

    // add tcp header
    tcp->checksum = 0;

    //addition info
    tcp->acknowledgementNumber = htonl(s->acknowledgementNumber);
    tcp->sequenceNumber = htonl(s->sequenceNumber);
    tcp->destPort = htons(s->remotePort);
    tcp->sourcePort = htons(s->localPort);
    tcp->offsetFields = htons((5 << 12) | flags);
    tcp->windowSize = htons(65535);
    tcp->urgentPointer = 0;



    sumIpWords(tcp, TcpLength, &sum);
    tcp->checksum = getIpChecksum(sum);

    // send packet with size = ether + udp hdr + ip header + udp_size
    putEtherPacket(ether, sizeof(etherHeader) + ipHeaderLength + TcpLength);
}



